package com.smart.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smart.app.model.DomainNotes;

@RestController
public class RestVueController {
	
	
	@GetMapping("/getcomments")
	public List<DomainNotes> getComment(){
		
		List<DomainNotes> dn = new ArrayList<DomainNotes>();
		DomainNotes notes =  new DomainNotes();
		DomainNotes notes1 = new DomainNotes();
		DomainNotes notes2 = new DomainNotes();
		DomainNotes notes3 = new DomainNotes();
		DomainNotes notes4 = new DomainNotes();
		notes.setComments("Note");
		notes1.setComments("Note1");
		notes2.setComments("Note2");
		notes3.setComments("Note3");
		notes4.setComments("Note4");
		dn.add(notes1);
		dn.add(notes2);
		dn.add(notes3);
		dn.add(notes4);
		return dn;
	}
	

}
